package com.top1.duuchniuk;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

public final class Main extends JavaPlugin implements Listener {

    @Override
    public void onEnable() {
        getServer().getPluginManager().registerEvents(this, this);
    }

    @Override
    public void onDisable() {
    }

    @EventHandler
    public void onEntityDamage(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof Player) {
            Player player = (Player) event.getDamager();
            ItemStack item = player.getInventory().getItemInMainHand();
            String type = item.getType().name();
            if (
                type.equals("WOODEN_SPEAR") ||
                type.equals("STONE_SPEAR") ||
                type.equals("COPPER_SPEAR") ||
                type.equals("IRON_SPEAR") ||
                type.equals("GOLDEN_SPEAR") ||
                type.equals("DIAMOND_SPEAR") ||
                type.equals("NETHERITE_SPEAR")
            ) {
                event.setDamage(event.getDamage() * 2.5);
            }
        }
    }
}
